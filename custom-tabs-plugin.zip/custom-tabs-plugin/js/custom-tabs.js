/**
 * A function that facilitates the transition between tabs and changes the design of the active tab.
 */

document.addEventListener("DOMContentLoaded", function () {
  const tabs = document.querySelectorAll(".titles67 a");
  const tabContents = document.querySelectorAll(".tab-content");
  tabs.forEach((tab) => {
    tab.addEventListener("click", function (e) {
      e.preventDefault();
      tabs.forEach((t) => t.parentElement.classList.remove("active"));
      tabContents.forEach((content) => (content.style.display = "none"));
      this.parentElement.classList.add("active");
      const activeTabContent = document.querySelector(
        this.getAttribute("href")
      );
      activeTabContent.style.display = "block";
    });
  });
  if (tabs.length > 0) {
    tabs[0].parentElement.classList.add("active");
    tabContents[0].style.display = "block";
  }
});
