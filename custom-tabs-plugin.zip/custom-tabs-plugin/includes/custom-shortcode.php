<?php 

/**
 * This function is responsible for retrieving the fields associated with the component in conjunction with ACF and embedding them in the website. 
 * Afterwards, it iterates over all the fields, and using an additional function, it checks whether the aforementioned field is valid or not.
 * return output
 */

function custom_tab_fields($id)
{
    $tabs = get_field('tabs', $id);

    if(!$tabs)
    {
      return '<p>No Tabs Found</p>';
    }


     $output = '<div class="tabs">';
    $output .= '<ul class="titles67">';

    foreach ($tabs as $i => $tab) {
        $output .= '<li><a href="#tab-' . ($i + 1) . '">' . check_tab_field($tab, 'tab_label', true) . '</a></li>';
    }
    $output .= '</ul>';

   foreach ($tabs as $i => $tab) {
  
    $output .= '<div id="tab-' . ($i + 1) . '" class="tab-content">';
    $output .= '<div class="container cont109">';
    $output .= '<div class="row">';
    $output .= '<div class="col-lg-8 col-md-12">';
    $background = check_tab_field($tab, 'background_for_tab'); 
    $style = '';
    if ($background) {
        $style = ' style="background-image: url(\'' . esc_url($background) . '\');"';
    }
      $output .= '<div class="person-details per34"' . $style . '>';

     $output .= '<div class="recom55">';  
    $output .= check_tab_field($tab, 'recommend');
     $output .= '</div>';

    $person = $tab['person']; 
    if ($person) {
      if (!empty($person['image78'])) 
        {
            $output .= '<div class="container809">'; 
            $output .= '<img src="' . esc_url($person['image78']) . '" alt="' . esc_attr($person['name']) . '" />'; 
        }
         $output .= '<div class="info80">';
        $output .= '<p class="name45">';
        $output .= check_tab_field($person, 'name');
        $output .= '</p>';
         $output .= '<p>';
        $output .= check_tab_field($person, 'title');
          $output .= '</div>'; 
       if (!empty($person['image78'])) 
       {
         $output .= '</div>'; 
       }    
         $logo = check_tab_field($tab, 'logoc90');
         if (!empty($logo)) 
         {
          $output .= '<img src="' . esc_url($logo) . '" alt="Logo Description">';
        }
    }
    $output .= '</div>'; 
    $output .= '</div>';  

  
    $output .= '<div class="col-lg-4 col-md-12">';
    $output .= '<div class="mobi14">';
    $output .= '<div class="percentage-details">';
    $output .= check_tab_field($tab, 'percentage');
    $output .= '</div>'; 

    $urls = $tab['urls355'];
    if ($urls) {
        $output .= '<div class="link-details info109">';
        if (!empty($urls['link255']) && !empty($urls['link_description255'])) {
             $output .= '<div class="link61">';
            $output .= '<a href="' . esc_url($urls['link255']) . '" target="_blank" rel="noopener noreferrer">' . esc_html($urls['link_description255']) . '</a>';
               $output .= '</div>';
        }
        $output .= '</div>';  
    }
    $output .= '</div>';  
    $output .= '</div></div>';  

 
    if (isset($tab['logo_gallery']) && is_array($tab['logo_gallery'])) {
        $output .= '<div class="row">';
        $output .= '<div class="col-12 images11">';
        $output .= '<span class="trust6">TRUSTED BY</span>';
        foreach ($tab['logo_gallery'] as $image) {
            $output .= '<img src="' . esc_url($image['url']) . '" alt="' . esc_attr($image['alt']) . '" class="img-fluid"/>';
        }
        $output .= '</div>';  
        $output .= '</div>';  
    }

    $output .= '</div>';  
    $output .= '</div>'; 
}
return $output;

} 


/**
 * A function that checks whether a field is valid or not.
 */

function check_tab_field($tab, $field_key, $is_html = false)
{
  if(isset($tab[$field_key]))
  {
    $content = $tab[$field_key];
    if (!($is_html))
    {
       return wp_kses_post($content);
    }
    else 
    {
      return esc_html($content);
    }
  }
  return '';
}


/**
 * A function that creates a shortcode, allowing the plugin to be embedded on any desired page.
 */
function create_shortcode($atts) 
{
    $atts  = shortcode_atts(array(
        'id' => '',
    ), $atts , 'custom_tabs');
    if (!$atts ['id']) {
        return '<p>No Tabs Group ID provided</p>';
    }
    return custom_tab_fields($atts['id']);
}
add_shortcode('custom_tabs', 'create_shortcode');
  
?>