<?php

/**
 * This function is responsible for creating the option to open/edit, etc.
 * A new page in the plugin in order to add more options in case different content is desired on different pages.
 */

function edit_content()
{
  $info= array (
    'name' => 'Tabs Groups',
    'singular_name' => 'Tabs Group',
    'menu_name' => 'Tabs Group',
    'name_admin_bar' => 'Tabs Group',
    'add_new' => 'Add New',
    'add_new_item' => 'Add New Tabs Group',
    'new_item' => 'New Tabs Group',
    'edit_item' => 'Edit Tabs Group',
    'view_item' => 'View Tabs Group',
    'all_items' => 'All Tabs Groups',
    "search_items" => 'Search Tabs Groups',
    'not_found' => "Not found",
    "not_found_in_trash" => "No tabs groups found in the Trash."

  );
  $args = array (
      'labels' => $info,
      'public' => true,
      'publicly_queryable' => true,
      'show_ui' => true,
      "show_in_menu" => false,
      "query_var" => true,
      "rewrite" => array('slug' => 'tabs_group'),
      'capability_type'=> 'post',
      'has_archive' => true,
      'hierarchical' => false,
      'menu_position' => null,
      'supports' => array('title'),
  );
  register_post_type( 'tabs_group', $args );
}
add_action( 'init', 'edit_content' );