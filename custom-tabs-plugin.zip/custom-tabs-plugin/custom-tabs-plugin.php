<?php 
/*
Plugin Name: Custom Tabs Plugin
Plugin URI: https://oriackerman.github.io/Portfolio/
Description: Plugin for dynamic content.
          Version: 1.0
          Author: Or
Author URI: https://oriackerman.github.io/Portfolio/
*/




include(plugin_dir_path(__FILE__) . 'includes/post-type.php');
include(plugin_dir_path(__FILE__) . 'includes/custom-shortcode.php');




/**
 * A function that adds the structure of the table in ACF to ACF, so that later in the plugin, it will be possible to insert the content.
 */
function import_acf_fields_on_activation() {  
    $json_path = plugin_dir_path(__FILE__) . 'acf-json/custom-tabs-new.json';
    if (file_exists($json_path)) {
        $json_data = file_get_contents($json_path);
        $fields = json_decode($json_data, true);
        if (!empty($fields) && function_exists('acf_add_local_field_group')) {
            foreach ($fields as $field) {
                acf_add_local_field_group($field);
            }
        }
    }
}
add_action('init', 'import_acf_fields_on_activation', 20);

function custom_plugin_scripts() {
    wp_register_script('custom-tabs', plugins_url('js/custom-tabs.js', __FILE__), array('jquery'), '1.0', true);
    wp_enqueue_script('custom-tabs');
}

add_action('wp_enqueue_scripts', 'custom_plugin_scripts');


function custom_styles() {
    wp_register_style('custom-styles', plugins_url('css/style.css', __FILE__), array(), '1.0', 'all');
    wp_enqueue_style('custom-styles');
}

add_action('wp_enqueue_scripts', 'custom_styles');


function custom_fonts() {
    wp_enqueue_style('https://use.typekit.net/wuz0gtr.css', false);
}

add_action('wp_enqueue_scripts', 'custom_fonts');


function load_bootstrap() {
    wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', array(), '4.5.2');
    wp_enqueue_script('popper-js', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js', array(), '1.16.0', true);
    wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery', 'popper-js'), '4.5.2', true);
}

add_action('wp_enqueue_scripts', 'load_bootstrap');

/**
 * A function that creates the option in the admin page to edit the plugin.
 */

function custom_tabs()
{
  add_menu_page(
    'edit.php?post_type=tabs_group',
    'Custom Tab',
    'manage_options',
    'custom-tabs-plugin',
    'main_page',
    
  );
  add_submenu_page(
        'custom-tabs-plugin',
        'Edit Tabs Groups',
        'Edit Tabs Groups',
        'manage_options',
        'edit.php?post_type=tabs_group'
    );
}
add_action('admin_menu', 'custom_tabs');

//A brief explanation of the plugin.
function main_page()
{
  ?>
  <div class="center2">
   <h1>Custom Tabs</h1>
   <p>Welcome to the Custom Tabs Plugin</p>
  </div>
 <?php
}




// A function that creates the shortcode location and allows copying it to place the shortcode wherever desired.
function add_custom_meta_box() {
    add_meta_box(
        'custom_meta_box',
        'Shortcode', 
        'display_custom_meta_box',
        'tabs_group', 
        'side', 
        'high'
    );
}
add_action('add_meta_boxes', 'add_custom_meta_box');

function display_custom_meta_box($post) {
    $shortcode = '[custom_tabs id="' . $post->ID . '"]';
    echo '<input type="text" readonly value="' . esc_attr($shortcode) . '" style="width:100%;">';
}


